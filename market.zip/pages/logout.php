<?php
	logout();
?>