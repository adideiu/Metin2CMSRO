<?php
	logout_shop();
?>